A Pen created at CodePen.io. 
You can find this one at https://codepen.io/Grsmto/pen/RPQPPB.


A hover effect using the gooey tricks (thanks to http://tympanus.net/codrops/2015/03/10/creative-gooey-effects/).

Built for dribbble shot here https://dribbble.com/shots/2544738-Not-your-average-button